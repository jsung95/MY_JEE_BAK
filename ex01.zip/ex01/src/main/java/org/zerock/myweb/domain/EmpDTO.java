package org.zerock.myweb.domain;

import lombok.Data;


//@NoArgsConstructor(access=lombok.AccessLevel.PUBLIC)
//@Getter
//@Setter
//@ToString
//@EqualsAndHashCode
@Data
public class EmpDTO {
	private Integer empno;
	private String ename;
	private Double sal;
	private Integer deptno;
	
	
	
}//end class
